# Nexii Online Website

This is the static website for **nexii.online**, prepared for deployment via **Netlify** and version control via **GitHub**.

## 🚀 Deployment Steps

1. Create a new GitHub repository named `nexii-online`.
2. Upload all files from this folder to that repository.
3. Go to [Netlify](https://app.netlify.com) → “Add new site” → “Import from GitHub”.
4. Connect your GitHub repo and deploy.
5. Add your custom domain `nexii.online` in Netlify domain settings.
6. Done — your website will go live automatically.

## ⚙️ Editing Guide

- To edit the site, just open `index.html` on GitHub → click the pencil icon → edit → “Commit changes”.
- Netlify will auto-update the live website within a minute.

## 🧩 Notes

- `_redirects` file ensures proper routing and prevents 404 errors.
- All content here is static (HTML/CSS/JS). No backend required.

